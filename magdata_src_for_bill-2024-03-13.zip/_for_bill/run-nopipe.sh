# run runMag without pipes.
#./runMag -b 1 -j -M 23 -A 10 -c 400 -U 140 -H -Z 
./runMag -b 1 -j -M 23 -A 10 -c 400 -H -Z 
