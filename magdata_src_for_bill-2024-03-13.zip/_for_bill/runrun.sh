./runMag -b 1 -j -M 23 -A 10 -c 400 -U 140 -Z > /home/web/wsroot/pipein.fifo
